package SSLFileTransferChat;

import java.io.*;
import java.net.*;
import java.rmi.*;
import java.util.*;

public class SSLChattingClient {
	
	static String serverIP = "";
	static int serverPort = 0000;
	static Socket chatting = null;
	static RmiChatting rmiChatting;
	
	public static void main(String[] args) throws IOException {

		if (args.length != 2) {
			// main �Լ� ���ڰ� �����ϸ� ���� ó��
			System.out.println("Usage: Classname ServerName ServerPort ");
			System.exit(1);
		}

		serverIP = args[0]; // Server IP
		serverPort = Integer.parseInt(args[1]); // Server Port
		
		try {
			chatting = new Socket(serverIP, serverPort); // �ش� Server IP, Port�� ����Ǵ� Socket ����
			
			// Rmi Registry�� Binding�� ��ü�� �ҷ���
			rmiChatting = (RmiChatting)Naming.lookup("rmi://" + chatting.getInetAddress().getHostAddress() +"/RmiChatting");
			
		} catch (BindException b) {
			// Binding ���� ó��
			System.out.println("Can't bind on: " + serverPort);
			System.exit(1);
		} catch (IOException i) {
			// I/O ���� ó��
			i.printStackTrace();
			System.out.println(i);
			System.exit(1);
		} catch(Exception e){
			// �� �� ���� ó��
			e.printStackTrace();
		}
		
		new Thread(new Receiver(chatting)).start();
		new Thread(new Sender(chatting, rmiChatting)).start();
	}
}
