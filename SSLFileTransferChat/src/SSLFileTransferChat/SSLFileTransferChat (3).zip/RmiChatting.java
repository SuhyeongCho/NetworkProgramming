package SSLFileTransferChat;

import java.rmi.Remote;

public interface RmiChatting extends Remote {

}
