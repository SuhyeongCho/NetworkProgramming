package SSLFileTransferChat;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;


public class RmiChattingImpl extends UnicastRemoteObject implements RmiChatting {

	protected RmiChattingImpl() throws RemoteException {
		super();
	}

}
